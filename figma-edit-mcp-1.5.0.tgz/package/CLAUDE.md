@AGENTS.md

